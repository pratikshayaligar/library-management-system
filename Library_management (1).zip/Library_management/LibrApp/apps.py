from django.apps import AppConfig


class LibrappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LibrApp'
