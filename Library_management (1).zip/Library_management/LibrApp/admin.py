from django.contrib import admin

from LibrApp.models import Book, User

# Register your models here.
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display=('name','contact','email','address','date')
    list_filter=('name',)
    search_fields=('name','date',)

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display=('book_name','pub_name')
    search_fields=('book_name','pub_name')
